﻿using PZ3.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PZ3
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            frContent.Navigate(new Autho()); 

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            frContent.GoBack();
        }

        private void frСontent_ContentRendered(object sender, EventArgs e)
        {
            if (frContent.CanGoBack)
                btnBack.Visibility = Visibility.Visible;
            else
                btnBack.Visibility = Visibility.Hidden;

        }

    }
    
}
