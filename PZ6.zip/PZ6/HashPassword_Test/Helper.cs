﻿using HashPassword_Test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashPassword_Test
{
    public class Helper
    {
        private static PhotocenterEntities2 _context;

        public static PhotocenterEntities2 GetContext()
        {
            if (_context == null)
            {
                _context = new PhotocenterEntities2();
            }
            return _context;
        }

        public void CreateUser(Clients user)
        {
            _context.Clients.Add(user); 
            _context.SaveChanges(); 
        }

        public void RemoveUser(int idUser)
        {
            var users = _context.Clients.Find(idUser); 
            _context.Clients.Remove(users); 
            _context.SaveChanges(); 
        }

        public List<Clients> FiltrUsers()
        {
            return _context.Clients.Where(x => x.LastName.StartsWith("M") || x.LastName.StartsWith("A")).ToList();
        }

        public List<Clients> SortUsers()
        {
            return _context.Clients.OrderBy(x => x.LastName).ToList();
        }

        public string GetUserTypes(Clients user)
        {
            return user.Authorization.AccountName.ToString();
        }

    }
}
