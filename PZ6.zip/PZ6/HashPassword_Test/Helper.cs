﻿using HashPassword_Test.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashPassword_Test
{
    public class Helper
    {
        private static demonEntities _context;

        public static demonEntities GetContext()
        {
            if (_context == null)
            {
                _context = new demonEntities();
            }
            return _context;
        }

        public void CreateUser(Clients user)
        {
            _context.Users.Add(user); 
            _context.SaveChanges(); 
        }

        public void UpdateUser(Clients user)
        {
            _context.Entry(user).State = System.Data.Entity.EntityState.Modified;
            _context.SaveChanges(); 
        }


        public void RemoveUser(int idUser)
        {
            var users = _context.Users.Find(idUser); 
            _context.Users.Remove(users); 
            _context.SaveChanges(); 
        }

        public List<Clients> FiltrUsers()
        {
            return _context.Users.Where(x => x.Name.StartsWith("M") || x.Name.StartsWith("A")).ToList();
        }

        public List<Clients> SortUsers()
        {
            return _context.Users.OrderBy(x => x.Name).ToList();
        }

        public string GetUserTypes(Clients user)
        {
            return user.Authorization.AccountName.ToString();
        }

    }
}
