﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModulesPR5.Models;

namespace ModulesPR5
{
    internal class Helper
    {
        private static PhotocenterEntities _context;

        public static PhotocenterEntities GetContext()
        {
            if (_context == null)
            {
                _context = new PhotocenterEntities();
            }
            return _context;
        }
        
        public static void CreateClient(Clients client)
        {
            _context.Clients.Add(client);
            _context.SaveChanges();
        }
        
        public static void UpdateClient(Clients client)
        {
            _context.Entry(client).State = System.Data.EntityState.Modified;
            _context.SaveChanges();
        }
        
        public static void RemoveClient(int idClient)
        {
            var users = _context.Clients.Find(idClient);
            _context.Clients.Remove(users);
            _context.SaveChanges();
        }
        
        public static int CreateAuth(Authorization auth)
        {
            _context.Authorization.Add(auth);
            _context.SaveChanges();
            _context.Entry(auth).GetDatabaseValues();
            return auth.AuthorizationID;
        }

        public static int GetRole(Roles role)
        {
            _context.Roles.Add(role);
            _context.SaveChanges();
            return role.RoleID;
        }
    }
}
