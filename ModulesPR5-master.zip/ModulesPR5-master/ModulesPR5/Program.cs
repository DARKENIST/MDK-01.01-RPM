using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HashPasswords;
using ModulesPR5.Models;

namespace ModulesPR5
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            
            Console.WriteLine("Создание новой учетной записи для соискателя");
            
            Console.WriteLine();

            int roleID = 1;
            string roleName = "Клиент";
            bool administrationRules = false;
            bool clientRules = true;
            bool dealerRules = false;

            Console.Write("Введите имя пользователя: ");
            string lastName = Console.ReadLine();
            
            Console.Write("Введите фамилию пользователя: ");
            string firstName = Console.ReadLine();
            
            Console.Write("Введите отчество пользователя (при наличии): ");
            string middleName = Console.ReadLine();
            
            Console.Write("Введите электронную почту пользователя: ");
            string email = Console.ReadLine();
            
            Console.Write("Введите ваш пол: ");
            string gender = Console.ReadLine();
            
            Console.WriteLine("Введите ваш возраст: ");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите логин пользователя: ");
            string login = Console.ReadLine();
            
            Console.Write("Введите пароль пользователя: ");
            string password = Console.ReadLine();

            Console.Write("Введите имя для аккаунта: ");
            string accName = Console.ReadLine();

            string hashPassw = HashPassword.GetHashPassword(password);
            
            Console.WriteLine($"Хэшированный пароль пользователя: {hashPassw}");

            Console.WriteLine($"Ваша роль: {roleName}");

            try
            {
                PhotocenterEntities db = Helper.GetContext();

                Authorization newAuth = new Authorization
                {
                    Login = login,
                    Password = hashPassw,
                    AccountName = accName,
                    RoleID = Convert.ToString(roleID)
                };
                
                int authId = Helper.CreateAuth(newAuth);
                Console.WriteLine($"Создана запись аутентификации с ID: {authId}");
                
                Clients newClient = new Clients
                {
                    LastName = lastName,
                    FirstName = firstName,
                    MiddleName = string.IsNullOrEmpty(middleName) ? null : middleName,
                    Email = email,
                    Gender = gender,
                    Age = age,
                    AuthorizationID = authId
                };

                Roles getRole = new Roles
                {
                    RoleID = roleID,
                    RoleName = roleName,
                    AdministrationRules = administrationRules,
                    ClientRules = clientRules,
                    DealerRules = dealerRules
                };

                // Добавляем в базу данных
                Helper.CreateClient(newClient);
                
                Console.WriteLine("Соискатель успешно создан!");
                Console.WriteLine($"ID нового соискателя: {newClient.ClientID}");

                roleID = roleID + 1;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}