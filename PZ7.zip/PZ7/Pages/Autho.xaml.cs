﻿using PZ3.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HashPassword_Test.Models;
using System.Windows.Threading;

namespace PZ3.Pages
{
    public partial class Autho : Page
    {
        int click;

        private static PhotocenterEntities2 _context;

        public static PhotocenterEntities2 GetContext()
        {
            if (_context == null)
            {
                _context = new PhotocenterEntities2();
            }
            return _context;
        }

        private int failedAttempts = 0;
        private const int MAX_ATTEMPTS = 3;
        private const int BLOCK_TIME_SECONDS = 10;
        private DispatcherTimer blockTimer;
        private int remainingSeconds;

        public bool IsAuthenticated { get; private set; } = false;
        public string Username { get; private set; } = string.Empty;

        public Autho()
        {
            InitializeComponent();
            InitializeTimer();
            UpdateAttemptsCounter();
            click = 0;

            tbLogin.Focus();
        }
        
        private void InitializeTimer()
        {
            blockTimer = new DispatcherTimer();
            blockTimer.Interval = TimeSpan.FromSeconds(15);
            blockTimer.Tick += BlockTimer_Tick;
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null, null));
        }

        private void GenerateCapctcha()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;

            string capctchaText = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = capctchaText;
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            click += 1;
            string login = tbLogin.Text.Trim();
            string password = tbPassword.Text.Trim();

            PhotocenterEntities2 db = new PhotocenterEntities2();

            GetContext();

            var user = db.Authorization.Where(x => x.Login == login && x.Password == password).FirstOrDefault();
            if (click == 1)
            {
                if (user != null)
                {
                    MessageBox.Show("Вы вошли под: " + user.Roles.RoleName.ToString());
                    LoadPage(user.Roles.RoleName.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Вы ввели логин или пароль неверно!");
                    GenerateCapctcha();
                    /*
                                         * Здесь должна быть оичстка поля с паролем
                    * Выводкапчи
                                         */
                }
                if (IsSystemBlocked())
                    return;

                if (AuthenticateUser(tbLogin.Text, tbPassword.Text))
                {
                    IsAuthenticated = true;
                    Username = tbLogin.Text;
                }
                else
                {
                    failedAttempts++;
                    UpdateAttemptsCounter();

                    if (failedAttempts >= MAX_ATTEMPTS)
                    {
                        BlockSystem();
                    }
                    else
                    {
                        MessageBox.Show($"Неверный логин или пароль! Осталось попыток: {MAX_ATTEMPTS - failedAttempts}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);

                        tbPassword.Clear();
                        tbPassword.Focus();
                    }
                }
            }
            else if(click > 1)
                    {
                if (user != null && tbCaptcha.Text == tblCaptcha.Text)
                {
                    MessageBox.Show("Вы вошли под: " + user.Roles.RoleName.ToString());
                    LoadPage(user.Roles.RoleName.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Введите данные заново!");
                }
            }
        }

        private bool AuthenticateUser(string login, string password)
        {
            return !string.IsNullOrEmpty(login) && !string.IsNullOrEmpty(password) && login == "admin" && password == "12345";
        }

        private bool IsSystemBlocked()
        {
            return blockTimer.IsEnabled;
        }

        private void BlockSystem()
        {
            tbLogin.IsEnabled = false;
            tbPassword.IsEnabled = false;
            tbCaptcha.IsEnabled = false;
            btnEnter.IsEnabled = false;

            remainingSeconds = BLOCK_TIME_SECONDS;
            tblockInfo.Text = $"Система заблокирована. Осталось: {remainingSeconds} сек.";
            tblockInfo.Visibility = Visibility.Visible;
            blockTimer.Start();
        }

        private void UnblockSystem()
        {
            tbLogin.IsEnabled = true;
            tbPassword.IsEnabled = true;
            tbCaptcha.IsEnabled = true;
            btnEnter.IsEnabled=true;

            tblockInfo.Visibility=Visibility.Collapsed;
            blockTimer.Stop();

            ResetAttempts();
            tbLogin.Clear();
            tbPassword.Clear();
            tbLogin.Focus();
        }
        private void ResetAttempts()
        {
            failedAttempts = 0;
            UpdateAttemptsCounter();
        }
        private void UpdateAttemptsCounter()
        {
            tbAttempts.Text = $"Неудачных попыток: {failedAttempts}";
        }

        private void BlockTimer_Tick(object sender, EventArgs e)
        {
            remainingSeconds--;
            tblockInfo.Text = $"Система заблокирована. Осталось: {remainingSeconds} сек.";

            if (remainingSeconds <= 0)
            {
                UnblockSystem();
            }
        }
     
        private void LoadPage(string _role, Authorization user)
        {
            click = 0;
            switch (_role)
            {
                case "Клиент":
                    NavigationService.Navigate(new Client(user, _role));
                    break;
            }
        }

        private void tbLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == System.Windows.Input.Key.Enter && !IsSystemBlocked())
            {
                btnEnter_Click(sender, e);
            }
        }

        private void tbPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == System.Windows.Input.Key.Enter && !IsSystemBlocked())
            {
                btnEnter_Click(sender, e);
            }
        }

    }
}
